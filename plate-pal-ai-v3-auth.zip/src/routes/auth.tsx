import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast, Toaster } from "sonner";
import { Zap, ShieldCheck, AlertCircle } from "lucide-react";

export const Route = createFileRoute("/auth")({
  component: AuthPage,
});

function AuthPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState<"login" | "signup" | "inactive">("login");
  const navigate = useNavigate();

  useEffect(() => {
    checkUserStatus();
  }, []);

  async function checkUserStatus() {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (profile) {
        const isExpired = new Date(profile.subscription_end_date) < new Date();
        if (!profile.is_active || isExpired) {
          setView("inactive");
        } else {
          navigate({ to: "/plates", replace: true });
        }
      } else {
        // Profile might not be created yet by trigger
        setView("inactive");
      }
    }
  }

  async function handleAuth(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (view === "signup") {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        toast.success("تم إنشاء الحساب! يرجى التواصل مع الإدارة للتفعيل.");
        setView("inactive");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        await checkUserStatus();
      }
    } catch (error: any) {
      toast.error(error.message || "فشلت العملية");
    } finally {
      setLoading(false);
    }
  }

  if (view === "inactive") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6 rtl" dir="rtl">
        <div className="max-w-md w-full bg-card border rounded-3xl p-8 text-center space-y-6 shadow-xl">
          <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center text-destructive mx-auto animate-bounce">
            <AlertCircle size={40} />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-black">الحساب غير مفعل</h1>
            <p className="text-muted-foreground text-sm">
              عذراً، حسابك غير مفعل حالياً أو انتهت فترة اشتراكك الشهري.
            </p>
          </div>
          <div className="bg-secondary/30 p-4 rounded-2xl text-xs font-bold text-secondary-foreground">
            يرجى التواصل مع الإدارة لتفعيل الحساب أو تجديد الاشتراك.
          </div>
          <button 
            onClick={() => window.open("https://wa.me/966XXXXXXXXX", "_blank")}
            className="w-full h-14 bg-primary text-primary-foreground rounded-2xl font-black text-lg shadow-lg shadow-primary/20 flex items-center justify-center gap-2"
          >
            تواصل مع الإدارة (واتساب)
          </button>
          <button onClick={() => { supabase.auth.signOut(); setView("login"); }} className="text-xs text-muted-foreground underline">تسجيل الخروج</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6 rtl" dir="rtl">
      <Toaster richColors position="top-center" />
      <div className="max-w-md w-full space-y-8">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-primary-foreground mx-auto shadow-lg shadow-primary/20 rotate-3">
            <Zap size={32} fill="currentColor" />
          </div>
          <h1 className="text-3xl font-black tracking-tighter">لوحاتي الذكي</h1>
          <p className="text-muted-foreground text-sm font-bold uppercase tracking-widest">Secure Access System</p>
        </div>

        <form onSubmit={handleAuth} className="bg-card border rounded-3xl p-8 shadow-sm space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-black uppercase mr-1">البريد الإلكتروني</label>
            <input 
              type="email" 
              required 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-12 rounded-xl bg-secondary/30 border-none px-4 outline-none focus:ring-2 ring-primary/20 font-bold"
              placeholder="name@example.com"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-black uppercase mr-1">كلمة المرور</label>
            <input 
              type="password" 
              required 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-12 rounded-xl bg-secondary/30 border-none px-4 outline-none focus:ring-2 ring-primary/20 font-bold"
              placeholder="••••••••"
            />
          </div>
          <button 
            disabled={loading}
            className="w-full h-14 bg-primary text-primary-foreground rounded-2xl font-black text-lg shadow-lg shadow-primary/20 transition-all active:scale-95 disabled:opacity-50"
          >
            {loading ? "جارٍ التحميل..." : view === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}
          </button>
          <button 
            type="button"
            onClick={() => setView(view === "login" ? "signup" : "login")}
            className="w-full text-xs font-bold text-muted-foreground hover:text-primary transition-colors"
          >
            {view === "login" ? "ليس لديك حساب؟ سجل الآن" : "لديك حساب بالفعل؟ سجل دخولك"}
          </button>
        </form>

        <div className="flex items-center justify-center gap-2 text-muted-foreground">
          <ShieldCheck size={16} />
          <span className="text-[10px] font-black uppercase tracking-widest">End-to-End Encrypted System</span>
        </div>
      </div>
    </div>
  );
}

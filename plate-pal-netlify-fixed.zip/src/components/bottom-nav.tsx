import { LayoutGrid, CheckSquare, Mic, Map, Shield } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Tab = "sorting" | "registration" | "checking" | "maps";

interface BottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) {
        supabase.from("profiles").select("is_admin").eq("id", data.user.id).single().then(({ data: profile }) => {
          if (profile?.is_admin) setIsAdmin(true);
        });
      }
    });
  }, []);

  const tabs = [
    { id: "sorting", label: "الفرز", icon: LayoutGrid },
    { id: "registration", label: "التسجيل", icon: Mic },
    { id: "checking", label: "التشييك", icon: CheckSquare },
    { id: "maps", label: "الخرائط", icon: Map },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-lg border-t z-50 px-4 pb-6 pt-2">
      <div className="flex items-center justify-around max-w-2xl mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as Tab)}
              className={`flex flex-col items-center gap-1 p-2 transition-all ${
                isActive ? "text-primary scale-110" : "text-muted-foreground"
              }`}
            >
              <Icon size={22} fill={isActive ? "currentColor" : "none"} />
              <span className="text-[10px] font-black">{tab.label}</span>
            </button>
          );
        })}
        {isAdmin && (
          <button
            onClick={() => navigate({ to: "/admin" })}
            className="flex flex-col items-center gap-1 p-2 text-muted-foreground hover:text-primary transition-all"
          >
            <Shield size={22} />
            <span className="text-[10px] font-black">الإدارة</span>
          </button>
        )}
      </div>
    </nav>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast, Toaster } from "sonner";
import { Users, UserPlus, ShieldAlert, Calendar, CheckCircle2, XCircle, LogOut, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminDashboard,
});

function AdminDashboard() {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    checkAdmin();
    fetchProfiles();
  }, []);

  async function checkAdmin() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return navigate({ to: "/auth" });
    
    const { data: profile } = await supabase
      .from("profiles")
      .select("is_admin")
      .eq("id", user.id)
      .single();

    if (!profile?.is_admin) {
      toast.error("عذراً، لا تملك صلاحية الوصول لهذه الصفحة");
      navigate({ to: "/plates" });
    } else {
      setIsAdmin(true);
    }
  }

  async function fetchProfiles() {
    setLoading(true);
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });
    
    if (error) toast.error("فشل تحميل قائمة المستخدمين");
    else setProfiles(data || []);
    setLoading(false);
  }

  async function toggleUserActive(id: string, currentStatus: boolean) {
    const { error } = await supabase
      .from("profiles")
      .update({ is_active: !currentStatus })
      .eq("id", id);

    if (error) toast.error("فشلت العملية");
    else {
      toast.success(currentStatus ? "تم حظر الحساب" : "تم تفعيل الحساب");
      fetchProfiles();
    }
  }

  async function extendSubscription(id: string) {
    const newDate = new Date();
    newDate.setDate(newDate.getDate() + 30);

    const { error } = await supabase
      .from("profiles")
      .update({ subscription_end_date: newDate.toISOString(), is_active: true })
      .eq("id", id);

    if (error) toast.error("فشل تمديد الاشتراك");
    else {
      toast.success("تم تمديد الاشتراك لمدة 30 يوماً");
      fetchProfiles();
    }
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background pb-10 rtl" dir="rtl">
      <Toaster richColors position="top-center" />
      
      <header className="p-6 bg-card border-b flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate({ to: "/plates" })} className="p-2 hover:bg-secondary rounded-xl transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-black">لوحة تحكم الإدارة</h1>
            <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Admin Control Center</p>
          </div>
        </div>
        <button onClick={() => supabase.auth.signOut()} className="p-2 text-destructive hover:bg-destructive/10 rounded-xl transition-colors">
          <LogOut size={20} />
        </button>
      </header>

      <main className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-primary/5 border border-primary/10 rounded-3xl p-6 space-y-1">
            <Users className="text-primary mb-2" size={24} />
            <p className="text-2xl font-black">{profiles.length}</p>
            <p className="text-xs text-muted-foreground font-bold">إجمالي المستخدمين</p>
          </div>
          <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-3xl p-6 space-y-1">
            <CheckCircle2 className="text-emerald-500 mb-2" size={24} />
            <p className="text-2xl font-black">{profiles.filter(p => p.is_active).length}</p>
            <p className="text-xs text-muted-foreground font-bold">الحسابات المفعلة</p>
          </div>
        </div>

        {/* Users List */}
        <section className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h2 className="font-black text-sm uppercase tracking-widest text-muted-foreground">قائمة المستخدمين</h2>
            <button onClick={fetchProfiles} className="text-[10px] font-bold text-primary hover:underline">تحديث القائمة</button>
          </div>

          <div className="space-y-3">
            {loading ? (
              <div className="text-center py-10 text-muted-foreground animate-pulse">جارٍ التحميل...</div>
            ) : profiles.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground bg-card border rounded-3xl">لا يوجد مستخدمين بعد</div>
            ) : profiles.map((user) => (
              <div key={user.id} className="bg-card border rounded-3xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg ${user.is_active ? 'bg-emerald-500/10 text-emerald-500' : 'bg-destructive/10 text-destructive'}`}>
                    {user.email?.[0].toUpperCase()}
                  </div>
                  <div>
                    <p className="font-black text-sm">{user.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${user.is_active ? 'bg-emerald-500/5 text-emerald-500 border-emerald-500/10' : 'bg-destructive/5 text-destructive border-destructive/10'}`}>
                        {user.is_active ? 'مفعل' : 'محظور'}
                      </span>
                      <span className="text-[9px] text-muted-foreground flex items-center gap-1 font-bold">
                        <Calendar size={10} /> ينتهي: {new Date(user.subscription_end_date).toLocaleDateString('ar-SA')}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button 
                    onClick={() => extendSubscription(user.id)}
                    className="flex-1 md:flex-none h-10 px-4 bg-primary/10 text-primary rounded-xl font-bold text-xs hover:bg-primary/20 transition-colors flex items-center justify-center gap-2"
                  >
                    <Calendar size={14} /> تمديد 30 يوم
                  </button>
                  <button 
                    onClick={() => toggleUserActive(user.id, user.is_active)}
                    className={`flex-1 md:flex-none h-10 px-4 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2 ${user.is_active ? 'bg-destructive/10 text-destructive hover:bg-destructive/20' : 'bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20'}`}
                  >
                    {user.is_active ? <XCircle size={14} /> : <CheckCircle2 size={14} />}
                    {user.is_active ? 'حظر' : 'تفعيل'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

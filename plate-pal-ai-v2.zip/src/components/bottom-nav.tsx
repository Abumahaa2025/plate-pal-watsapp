import { LayoutGrid, CheckSquare, Mic, Map } from "lucide-react";

type Tab = "sorting" | "registration" | "checking" | "maps";

interface BottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const tabs = [
    { id: "sorting", label: "الفرز", icon: LayoutGrid },
    { id: "registration", label: "التسجيل", icon: Mic },
    { id: "checking", label: "التشييك", icon: CheckSquare },
    { id: "maps", label: "الخرائط", icon: Map },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t flex justify-around items-center h-16 px-2 pb-safe z-50">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id as Tab)}
            className={`flex flex-col items-center justify-center flex-1 gap-1 transition-colors ${
              isActive ? "text-primary" : "text-muted-foreground"
            }`}
          >
            <div className={`p-1 rounded-xl ${isActive ? "bg-primary/10" : ""}`}>
              <Icon size={20} />
            </div>
            <span className="text-[10px] font-bold">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { parsePlateFile, naturalCompare, exportPlates, type Plate } from "@/lib/plates";
import { toast, Toaster } from "sonner";
import { BottomNav } from "@/components/bottom-nav";
import { createWorker } from "tesseract.js";
import { 
  FileText, 
  X, 
  Check, 
  Eye, 
  EyeOff, 
  Upload, 
  Share2, 
  Copy, 
  Database,
  ArrowUpDown,
  Filter,
  Mic,
  CheckSquare,
  Map as MapIcon,
  Camera,
  Brain,
  MessageSquare,
  Zap
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/plates")({
  component: PlatesPage,
  head: () => ({
    meta: [
      { title: "لوحاتي — نظام الفرز الذكي" },
      { name: "description", content: "إدارة أرقام اللوحات بالذكاء الاصطناعي، OCR، والأوامر الصوتية." },
    ],
  }),
});

type Tab = "sorting" | "registration" | "checking" | "maps";
type SortMode = "asc" | "desc" | "none";

function PlatesPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("sorting");
  const [email, setEmail] = useState<string>("");
  const [filename, setFilename] = useState<string>("");
  const [plates, setPlates] = useState<Plate[]>([]);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortMode>("asc");
  const [dedupe, setDedupe] = useState(true);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [isProcessingOCR, setIsProcessingOCR] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [loading, setLoading] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
    if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("shared") === "1") {
      pickupSharedFile();
    }
  }, []);

  // --- OCR Logic ---
  async function handleOCR(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setIsProcessingOCR(true);
    toast.info("جارٍ التعرف على اللوحات من الصورة...");
    
    try {
      const worker = await createWorker('ara+eng');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();
      
      // Simple regex to find potential plate numbers (3-4 digits + 1-3 Arabic letters)
      const foundPlates = text.match(/(\d{3,4})\s*([\u0600-\u06FF]{1,3})/g) || [];
      
      if (foundPlates.length > 0) {
        const newPlates: Plate[] = foundPlates.map((val, idx) => ({
          value: val.trim(),
          row: plates.length + idx + 1
        }));
        setPlates(prev => [...prev, ...newPlates]);
        toast.success(`تم اكتشاف ${newPlates.length} لوحة بنجاح`);
      } else {
        toast.error("لم يتم العثور على لوحات واضحة في الصورة");
      }
    } catch (err) {
      toast.error("فشل نظام التعرف الضوئي (OCR)");
    } finally {
      setIsProcessingOCR(false);
    }
  }

  // --- Voice Commands Logic ---
  function toggleVoice() {
    if (!('webkitSpeechRecognition' in window)) {
      toast.error("متصفحك لا يدعم الأوامر الصوتية");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = 'ar-SA';
    recognition.continuous = false;
    
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    
    recognition.onresult = (event: any) => {
      const command = event.results[0][0].transcript.toLowerCase();
      console.log("Voice Command:", command);
      
      if (command.includes("فرز") || command.includes("ترتيب")) {
        setSort(sort === "asc" ? "desc" : "asc");
        toast.success("تم تغيير الترتيب صوتياً");
      } else if (command.includes("تصدير") || command.includes("حفظ")) {
        handleShare("xlsx");
      } else if (command.includes("بحث عن")) {
        const q = command.replace("بحث عن", "").trim();
        setQuery(q);
      } else {
        toast.info(`سمعت: ${command}`);
      }
    };
    
    recognition.start();
  }

  // --- Standard Logic ---
  async function pickupSharedFile() {
    try {
      const res = await fetch("/__shared-file");
      if (!res.ok) return;
      const name = decodeURIComponent(res.headers.get("x-filename") || "shared.xlsx");
      const buf = await res.arrayBuffer();
      await handleBuffer(buf, name);
      window.history.replaceState({}, "", "/plates");
    } catch {}
  }

  async function handleBuffer(buf: ArrayBuffer, name: string, pass?: string) {
    setIsUploading(true);
    setUploadProgress(0);
    const interval = setInterval(() => setUploadProgress(prev => (prev < 90 ? prev + 10 : prev)), 100);

    try {
      const parsed = parsePlateFile(buf, name, pass || password);
      clearInterval(interval);
      setUploadProgress(100);
      setTimeout(() => {
        if (parsed.length === 0) toast.error("لم يتم العثور على لوحات");
        else { setPlates(parsed); setFilename(name); toast.success(`تم استيراد ${parsed.length} لوحة`); }
        setIsUploading(false);
      }, 500);
    } catch (e) {
      clearInterval(interval);
      setIsUploading(false);
      toast.error("خطأ في قراءة الملف");
    }
  }

  const processed = useMemo(() => {
    let list = plates;
    if (dedupe) {
      const seen = new Set<string>();
      list = list.filter(p => {
        const key = p.value.replace(/\s+/g, "").toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key); return true;
      });
    }
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(p => p.value.toLowerCase().includes(q));
    }
    if (sort !== "none") {
      list = [...list].sort((a, b) => {
        const c = naturalCompare(a.value, b.value);
        return sort === "asc" ? c : -c;
      });
    }
    return list;
  }, [plates, query, sort, dedupe]);

  async function handleShare(format: "xlsx" | "csv") {
    if (processed.length === 0) return;
    toast.info("جارٍ التصدير والمشاركة...");
    exportPlates(processed, filename || "plates", format);
    if (navigator.share) {
      try {
        await navigator.share({
          title: "لوحاتي - ملف معالج",
          text: `تمت معالجة ${processed.length} لوحة بنجاح.`,
          url: window.location.origin
        });
      } catch (err) {}
    }
  }

  const stats = useMemo(() => {
    if (processed.length === 0) return null;
    const charMap: Record<string, number> = {};
    const digitMap: Record<string, number> = {};
    processed.forEach(p => {
      const chars = p.value.match(/[\u0600-\u06FFa-zA-Z]/g) || [];
      chars.forEach(c => charMap[c] = (charMap[c] || 0) + 1);
      const digits = p.value.match(/\d/g) || [];
      digits.forEach(d => digitMap[d] = (digitMap[d] || 0) + 1);
    });
    return { 
      topChars: Object.entries(charMap).sort((a, b) => b[1] - a[1]).slice(0, 5),
      topDigits: Object.entries(digitMap).sort((a, b) => b[1] - a[1]).slice(0, 5)
    };
  }, [processed]);

  return (
    <div className="min-h-screen bg-background pb-24 rtl" dir="rtl">
      <Toaster richColors position="top-center" />
      
      {/* Top Header */}
      <header className="p-4 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-40 border-b">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/20">
            <Zap size={20} fill="currentColor" />
          </div>
          <div>
            <h1 className="text-lg font-black leading-none">لوحاتي الذكي</h1>
            <p className="text-[10px] text-muted-foreground font-bold mt-1 uppercase tracking-tighter">AI Powered Platform</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={toggleVoice} className={`p-2 rounded-full transition-all ${isListening ? 'bg-destructive text-destructive-foreground animate-pulse' : 'hover:bg-secondary text-muted-foreground'}`}>
            <Mic size={20} />
          </button>
          <button className="p-2 hover:bg-secondary rounded-full text-muted-foreground">
            <Filter size={20} />
          </button>
        </div>
      </header>

      <main className="p-4 space-y-4 max-w-2xl mx-auto">
        
        {activeTab === "sorting" && (
          <>
            {/* AI Action Bar */}
            <section className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
              <button 
                onClick={() => cameraInput.current?.click()}
                className="flex-shrink-0 flex items-center gap-2 bg-primary/10 text-primary px-4 py-2.5 rounded-2xl font-bold text-xs border border-primary/20"
              >
                <Camera size={16} />
                مسح بالذكاء الاصطناعي
                <input ref={cameraInput} type="file" accept="image/*" capture="environment" onChange={handleOCR} className="hidden" />
              </button>
              <button className="flex-shrink-0 flex items-center gap-2 bg-secondary/50 text-muted-foreground px-4 py-2.5 rounded-2xl font-bold text-xs border">
                <Brain size={16} />
                تحليل الأنماط
              </button>
              <button className="flex-shrink-0 flex items-center gap-2 bg-secondary/50 text-muted-foreground px-4 py-2.5 rounded-2xl font-bold text-xs border">
                <MessageSquare size={16} />
                مساعد لوحاتي
              </button>
            </section>

            {/* Data Input Card */}
            <section className="rounded-3xl bg-card border shadow-sm overflow-hidden">
              <div className="p-4 border-b bg-secondary/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Database size={18} className="text-primary" />
                  <h2 className="font-bold">بيانات الفرز</h2>
                </div>
                <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full font-black">
                  {plates.length} سجل
                </span>
              </div>

              <div className="p-5 space-y-4">
                <div 
                  onClick={() => fileInput.current?.click()}
                  className="border-2 border-dashed border-primary/20 rounded-2xl p-6 flex flex-col items-center justify-center gap-3 bg-primary/5 hover:bg-primary/10 transition-all cursor-pointer group"
                >
                  <input ref={fileInput} type="file" accept=".xlsx,.xls,.csv" onChange={onFile} className="hidden" />
                  <div className="w-12 h-12 bg-background rounded-2xl shadow-sm flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                    {filename ? <FileText size={24} /> : <Upload size={24} />}
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-sm">{filename || "اضغط لاختيار ملف البيانات"}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">Excel, CSV, Image (OCR)</p>
                  </div>
                </div>

                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="كلمة المرور للملفات المشفرة"
                    className="w-full h-12 rounded-xl bg-secondary/30 border-none px-4 outline-none focus:ring-2 ring-primary/20"
                  />
                  <button onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                  <button className="absolute right-2 top-2 bottom-2 px-4 bg-primary text-primary-foreground rounded-lg text-xs font-bold shadow-sm">تأكيد</button>
                </div>

                {(isUploading || isProcessingOCR) && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-tighter">
                      <span className="text-primary">{isProcessingOCR ? "AI PROCESSING..." : "UPLOADING..."}</span>
                      <span>{isProcessingOCR ? "..." : `${uploadProgress}%`}</span>
                    </div>
                    <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div className={`h-full bg-primary transition-all duration-300 ${isProcessingOCR ? 'animate-shimmer' : ''}`} style={{ width: isProcessingOCR ? '100%' : `${uploadProgress}%` }} />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <button onClick={() => setSort(sort === "asc" ? "desc" : "asc")} className="h-12 rounded-xl bg-secondary/50 font-bold flex items-center justify-center gap-2 hover:bg-secondary transition-colors">
                    <ArrowUpDown size={18} /> فرز جديد
                  </button>
                  <button onClick={() => toast.success("بدء الفرز الذكي...")} className="h-12 rounded-xl bg-primary text-primary-foreground font-black flex items-center justify-center gap-2 shadow-lg shadow-primary/20">
                    <Check size={18} /> فرز كلي
                  </button>
                </div>
              </div>
            </section>

            {/* Statistics Section */}
            {stats && (
              <section className="grid grid-cols-2 gap-3">
                <div className="rounded-3xl bg-card border p-4 shadow-sm">
                  <p className="text-[9px] font-black text-muted-foreground mb-3 uppercase tracking-widest border-b pb-1">Top Characters</p>
                  <div className="flex flex-wrap gap-1.5">
                    {stats.topChars.map(([c]) => (
                      <span key={c} className="w-8 h-8 bg-secondary/50 rounded-lg flex items-center justify-center text-xs font-black border border-primary/5">{c}</span>
                    ))}
                  </div>
                </div>
                <div className="rounded-3xl bg-card border p-4 shadow-sm">
                  <p className="text-[9px] font-black text-muted-foreground mb-3 uppercase tracking-widest border-b pb-1">Top Digits</p>
                  <div className="flex flex-wrap gap-1.5">
                    {stats.topDigits.map(([d]) => (
                      <span key={d} className="w-8 h-8 bg-primary/5 text-primary rounded-lg flex items-center justify-center text-xs font-black border border-primary/10">{d}</span>
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Referral Section */}
            <section className="rounded-3xl bg-card border p-5 space-y-4 shadow-sm">
              <div className="flex items-center gap-2 text-primary">
                <Zap size={18} />
                <h2 className="font-bold">ملف الإحالة الذكي</h2>
              </div>
              <div className="flex gap-3">
                <button className="flex-1 h-14 rounded-2xl bg-primary/10 text-primary font-black text-lg flex items-center justify-center gap-2 border border-primary/20">
                  <Database size={20} /> فرز كلي
                </button>
                <button onClick={() => toast.success("تم النسخ")} className="w-14 h-14 rounded-2xl border flex items-center justify-center text-muted-foreground hover:bg-secondary">
                  <Copy size={22} />
                </button>
                <button onClick={() => handleShare("xlsx")} className="w-14 h-14 rounded-2xl border flex items-center justify-center text-muted-foreground hover:bg-secondary">
                  <Share2 size={22} />
                </button>
              </div>
            </section>

            {/* Preview List */}
            {processed.length > 0 && (
              <section className="space-y-3">
                <div className="flex items-center justify-between px-2">
                  <h3 className="font-black text-[10px] uppercase tracking-widest text-muted-foreground">Preview ({processed.length})</h3>
                  <button onClick={() => setDedupe(!dedupe)} className={`text-[10px] font-bold px-3 py-1 rounded-full border ${dedupe ? 'bg-primary/10 text-primary border-primary/20' : ''}`}>Dedupe</button>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {processed.slice(0, 15).map((p, i) => (
                    <div key={i} className="plate-chip text-[10px] h-11 shadow-sm border-primary/10 hover:border-primary/30 transition-all">{p.value}</div>
                  ))}
                </div>
              </section>
            )}
          </>
        )}

        {/* Other Tabs Content */}
        {activeTab === "registration" && (
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
            <div className="w-28 h-28 bg-primary/10 rounded-full flex items-center justify-center text-primary animate-pulse border-4 border-primary/5 shadow-2xl">
              <Mic size={48} />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-black">التسجيل الصوتي الذكي</h2>
              <p className="text-xs text-muted-foreground max-w-xs mx-auto">نظام تحويل الصوت إلى بيانات رقمية فوراً. ابدأ الإملاء وسنقوم بالباقي.</p>
            </div>
            <button onClick={toggleVoice} className={`h-16 px-12 rounded-2xl font-black text-lg shadow-xl transition-all ${isListening ? 'bg-destructive text-destructive-foreground' : 'bg-primary text-primary-foreground shadow-primary/20'}`}>
              {isListening ? "جارٍ الاستماع..." : "ابدأ التسجيل"}
            </button>
          </div>
        )}

        {activeTab === "checking" && (
          <div className="space-y-4">
            <section className="rounded-3xl bg-card border p-6 text-center space-y-5 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mx-auto"><CheckSquare size={32} /></div>
              <h2 className="text-xl font-black">التشييك اللحظي</h2>
              <p className="text-xs text-muted-foreground">أدخل أرقام اللوحات للتحقق من حالتها الأمنية والبيانات المرتبطة بها.</p>
              <textarea className="w-full h-40 rounded-2xl bg-secondary/30 border-none p-4 outline-none focus:ring-2 ring-primary/20 text-sm font-bold" placeholder="أدخل اللوحات هنا (مثال: 1234 أ ب ج)..."></textarea>
              <button className="w-full h-14 bg-primary text-primary-foreground rounded-2xl font-black text-lg shadow-lg shadow-primary/20">بدء التحقق الذكي</button>
            </section>
          </div>
        )}

        {activeTab === "maps" && (
          <div className="space-y-4">
            <div className="h-[450px] rounded-3xl bg-secondary/20 border-2 border-dashed flex flex-col items-center justify-center text-muted-foreground gap-3 relative overflow-hidden group">
              <MapIcon size={48} className="group-hover:scale-110 transition-transform" />
              <p className="font-black text-sm">خريطة الرصد الجغرافي</p>
              <p className="text-[10px] font-bold">توزيع اللوحات المستوردة جغرافياً</p>
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent pointer-events-none" />
            </div>
            <section className="rounded-3xl bg-card border p-5 shadow-sm">
              <h3 className="font-black text-[10px] uppercase tracking-widest text-muted-foreground mb-4">Live Tracking</h3>
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-secondary/10 rounded-2xl border border-transparent hover:border-primary/10 transition-all">
                    <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary"><MapIcon size={18} /></div>
                    <div className="flex-1">
                      <p className="text-sm font-black">المنطقة الصناعية - الرياض</p>
                      <p className="text-[10px] text-muted-foreground font-bold">تم رصد لوحة (1234 أ ب ج) منذ قليل</p>
                    </div>
                    <span className="text-[9px] font-black text-primary bg-primary/5 px-2 py-1 rounded-md">LIVE</span>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
